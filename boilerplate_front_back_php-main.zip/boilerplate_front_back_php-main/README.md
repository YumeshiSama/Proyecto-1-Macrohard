# boilerplate_front_back_php

Este es un modelo basico de frontend en html y backend en php

En el archivo router.php se debe agregar el path relativo. ej: 
si la url del server es http://localhost/proyectos/boilerplate/server se debe agregar proyectos/boilerplate/server en la linea 6 donde dice 
    $route = str_replace("proyectos/boilerplate/server", "", $route);


